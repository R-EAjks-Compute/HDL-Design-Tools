This is a CMake :ref:`Environment Variable <CMake Language
Environment Variables>`. Its initial value is taken from
the calling process environment.
