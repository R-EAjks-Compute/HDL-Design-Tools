CMAKE_CONFIG_TYPE
-----------------

.. include:: include/ENV_VAR.rst

The default build configuration for :ref:`Build Tool Mode` and
``ctest`` build handler when there is no explicit configuration given.
